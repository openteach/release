/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
ReactiveVar = Package['reactive-var'].ReactiveVar;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
ECMAScript = Package.ecmascript.ECMAScript;
FlowRouter = Package['kadira:flow-router'].FlowRouter;
ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;
GitHub = Package['bruz:github-api'].GitHub;
Base64 = Package['ostrio:base64'].Base64;
check = Package.check.check;
Match = Package.check.Match;
ValidatedMethod = Package['mdg:validated-method'].ValidatedMethod;
Picker = Package['meteorhacks:picker'].Picker;
Astro = Package['jagi:astronomy'].Astro;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
meteorInstall = Package.modules.meteorInstall;
Buffer = Package.modules.Buffer;
process = Package.modules.process;
Symbol = Package['ecmascript-runtime'].Symbol;
Map = Package['ecmascript-runtime'].Map;
Set = Package['ecmascript-runtime'].Set;
meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
Promise = Package.promise.Promise;
Accounts = Package['accounts-base'].Accounts;
Autoupdate = Package.autoupdate.Autoupdate;

