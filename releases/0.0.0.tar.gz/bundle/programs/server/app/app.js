var require = meteorInstall({"imports":{"api":{"repositories":{"integrations":{"github.js":["meteor/meteor","../../../collections/instructor.js","../../../collections/books.js","remarkable","remarkable-meta",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/repositories/integrations/github.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({fetchInstructor:function(){return fetchInstructor},fetchCourse:function(){return fetchCourse}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Instructor;module.import('../../../collections/instructor.js',{"Instructor":function(v){Instructor=v}});var Books;module.import('../../../collections/books.js',{"Books":function(v){Books=v}});var Remarkable;module.import('remarkable',{"default":function(v){Remarkable=v}});var Meta;module.import('remarkable-meta',{"default":function(v){Meta=v}});
                                                                                                                      //
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      //
                                                                                                                      // 6
                                                                                                                      // 7
                                                                                                                      //
// Setup access to github                                                                                             //
var github = new GitHub({                                                                                             // 10
    version: "3.0.0", // required                                                                                     // 11
    timeout: 5000, // optional                                                                                        // 12
    protocol: "https",                                                                                                // 13
    headers: {                                                                                                        // 14
        "user-agent": "Greetings from OpenTeach" // GitHub is happy with a unique user agent                          // 15
    }                                                                                                                 // 14
});                                                                                                                   // 10
github.authenticate({                                                                                                 // 18
    type: "oauth",                                                                                                    // 19
    token: Meteor.settings.githubApi.access_token                                                                     // 20
});                                                                                                                   // 18
var getContent = Meteor.wrapAsync(github.repos.getContent, github.repos);                                             // 22
                                                                                                                      //
var fetchCourse = function fetchCourse(ghUser, ghRepo, base) {                                                        // 25
    // Find the Course.md                                                                                             //
    var courseTxt = getContent({                                                                                      // 27
        user: ghUser,                                                                                                 // 28
        repo: ghRepo,                                                                                                 // 29
        path: base + "/Book.md" });                                                                                   // 30
                                                                                                                      //
    // Parse content to get metadata                                                                                  //
    var bookIndexRaw = Base64.decode(courseTxt.content);                                                              // 33
    var remarkable = new Remarkable();                                                                                // 34
    remarkable.use(Meta);                                                                                             // 35
    remarkable.render(bookIndexRaw);                                                                                  // 36
    var book = remarkable.meta;                                                                                       // 37
                                                                                                                      //
    console.log("Fetching book: " + book.title);                                                                      // 39
                                                                                                                      //
    // Fetch all lectures of course                                                                                   //
    chapterObjects = [];                                                                                              // 42
    for (var i = 0; i < book.chapters.length; i++) {                                                                  // 43
        try {                                                                                                         // 44
            resp = getContent({                                                                                       // 45
                user: ghUser,                                                                                         // 46
                repo: ghRepo,                                                                                         // 47
                path: base + "/" + book.chapters[i] });                                                               // 48
        } catch (e) {                                                                                                 // 49
            console.log("Not found: " + book.chapters[i]);                                                            // 50
        }                                                                                                             // 51
                                                                                                                      //
        // Make sure there was a course                                                                               //
        if (typeof resp.content !== 'undefined') {                                                                    // 54
                                                                                                                      //
            // Parse md content to get metadata                                                                       //
            var fileContent = Base64.decode(resp.content);                                                            // 57
            var md = new Remarkable();                                                                                // 58
            md.use(Meta);                                                                                             // 59
            md.render(fileContent);                                                                                   // 60
            var metadata = md.meta;                                                                                   // 61
                                                                                                                      //
            console.log("got chapter: " + metadata.title);                                                            // 63
                                                                                                                      //
            chapterObjects.push({                                                                                     // 65
                meta: metadata,                                                                                       // 66
                content: fileContent                                                                                  // 67
            });                                                                                                       // 65
        }                                                                                                             // 69
    }                                                                                                                 // 70
                                                                                                                      //
    // Assemble and validate object for the database                                                                  //
    var bookColObj = {                                                                                                // 73
        title: book.title,                                                                                            // 74
        index: {                                                                                                      // 75
            meta: book,                                                                                               // 76
            content: bookIndexRaw                                                                                     // 77
        },                                                                                                            // 75
        chapters: chapterObjects                                                                                      // 79
    };                                                                                                                // 73
    // Books.schema.validate(bookColObj);                                                                             //
                                                                                                                      //
    // create or update course to db                                                                                  //
    Books.upsert({ title: book.title }, { $set: bookColObj });                                                        // 84
};                                                                                                                    // 85
                                                                                                                      //
// We expect a file names instructor.json in the root of a github repo                                                //
var fetchInstructor = function fetchInstructor(ghUser, ghRepo) {                                                      // 88
    // Find the Course.md                                                                                             //
    var instructorObj = getContent({                                                                                  // 90
        user: ghUser,                                                                                                 // 91
        repo: ghRepo,                                                                                                 // 92
        path: "/instructor.json" });                                                                                  // 93
                                                                                                                      //
    // Parse content to get metadata                                                                                  //
    var iObj = JSON.parse(Base64.decode(instructorObj.content));                                                      // 96
    console.log(iObj);                                                                                                // 97
                                                                                                                      //
    // Assemble and validate object for the database                                                                  //
    // Instructor.schema.validate(iObj);                                                                              //
                                                                                                                      //
    // Upload instructor to db                                                                                        //
    //Instructor.upsert({title : course.title}, {$set : course});                                                     //
    return iObj;                                                                                                      // 104
};                                                                                                                    // 105
                                                                                                                      //
                                                                                                                      // 107
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"methods.js":["meteor/check","meteor/mdg:validated-method","./integrations/github.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/api/repositories/methods.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({importRepoData:function(){return importRepoData}});var check;module.import('meteor/check',{"check":function(v){check=v}});var ValidatedMethod;module.import('meteor/mdg:validated-method',{"ValidatedMethod":function(v){ValidatedMethod=v}});var fetchInstructor,fetchCourse;module.import('./integrations/github.js',{"fetchInstructor":function(v){fetchInstructor=v},"fetchCourse":function(v){fetchCourse=v}});
                                                                                                                      // 2
                                                                                                                      //
                                                                                                                      // 4
                                                                                                                      //
var importRepoData = function importRepoData() {                                                                      // 6
    var instructor = fetchInstructor(Meteor.settings.instructor.ghUser, Meteor.settings.instructor.ghRepo);           // 7
                                                                                                                      //
    for (var i = 0; i < instructor.books.length; i++) {                                                               // 9
        fetchCourse(instructor.books[i].ghUser, instructor.books[i].ghRepo, instructor.books[i].base);                // 10
    }                                                                                                                 // 13
};                                                                                                                    // 14
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"common":{"accounts.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/common/accounts.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Accounts.config({                                                                                                     // 1
    loginExpirationInDays: 5                                                                                          // 2
});                                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"develop.js":["meteor/meteor","meteor/accounts-base","../../collections/books.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/server/develop.js                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});var Book,Books;module.import('../../collections/books.js',{"Book":function(v){Book=v},"Books":function(v){Books=v}});// Setup everything for development
                                                                                                                      //
                                                                                                                      // 3
                                                                                                                      // 4
                                                                                                                      // 5
                                                                                                                      //
/**                                                                                                                   //
 * This function is made when the server is started in debug mode                                                     //
 * It sets up:                                                                                                        //
 */                                                                                                                   //
function debug() {                                                                                                    // 13
    try {                                                                                                             // 14
        Accounts.createUser({                                                                                         // 15
            username: "test",                                                                                         // 16
            email: "test@example.com",                                                                                // 17
            password: "test"                                                                                          // 18
        });                                                                                                           // 15
    } catch (e) {}                                                                                                    // 20
    // User was already set up                                                                                        //
                                                                                                                      //
                                                                                                                      //
    // Setup instructor                                                                                               //
    // The instructor object resides in a file in a github repository.                                                //
    var demoInstructor = {                                                                                            // 27
        books: [{                                                                                                     // 28
            url: "git@github.com:openteach/test-course.git",                                                          // 30
            base: "/course"                                                                                           // 31
        }, {                                                                                                          // 29
            url: "git@github.com:openteach/test-instructor.git",                                                      // 34
            base: "/some-course"                                                                                      // 35
        }]                                                                                                            // 33
    };                                                                                                                // 27
                                                                                                                      //
    // Setup Demo book                                                                                                //
    if (!Book.findOne({ title: "Test Course" })) {                                                                    // 41
        var demoBook = new Book({                                                                                     // 42
            title: "Test Course",                                                                                     // 43
            index: {                                                                                                  // 44
                meta: {                                                                                               // 45
                    title: "Welcome"                                                                                  // 46
                },                                                                                                    // 45
                content: "# This is the frontpage text of the course."                                                // 48
            },                                                                                                        // 44
            chapters: [{                                                                                              // 50
                meta: {                                                                                               // 52
                    title: "Test lecture 1"                                                                           // 53
                },                                                                                                    // 52
                content: "# Welcome to the First Lecture \nMore text here"                                            // 55
            }, {                                                                                                      // 51
                meta: {                                                                                               // 58
                    title: "Test lecture 2"                                                                           // 59
                },                                                                                                    // 58
                content: "# Welcome to the Second! Lecture \nAlright"                                                 // 61
            }]                                                                                                        // 57
        });                                                                                                           // 42
        demoBook.save();                                                                                              // 65
    }                                                                                                                 // 66
}                                                                                                                     // 67
                                                                                                                      //
// If debug flag is set, run function                                                                                 //
Meteor.startup(function () {                                                                                          // 70
    debug();                                                                                                          // 71
});                                                                                                                   // 72
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["../common/accounts.js","./publications.js","./routes.js","./develop.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/server/index.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.import('../common/accounts.js');module.import('./publications.js');module.import('./routes.js');               // 1
                                                                                                                      // 2
                                                                                                                      // 3
                                                                                                                      //
// We do development                                                                                                  //
if (Meteor.isDevelopment) {module.import('./develop.js');                                                             // 6
                                                                                                                      // 7
}                                                                                                                     // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"publications.js":["../../collections/books.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/server/publications.js                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Books;module.import('../../collections/books.js',{"Books":function(v){Books=v}});                                 // 1
                                                                                                                      //
// Publish books                                                                                                      //
Meteor.publish('books', function () {                                                                                 // 4
    return Books.find();                                                                                              // 5
});                                                                                                                   // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"routes.js":["../../api/repositories/methods.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/startup/server/routes.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var importRepoData;module.import('../../api/repositories/methods.js',{"importRepoData":function(v){importRepoData=v}});
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 3
    Picker.route('/api/v1/import/github', function (params, req, res, next) {                                         // 4
        importRepoData();                                                                                             // 5
        res.end("Done");                                                                                              // 6
    });                                                                                                               // 7
}                                                                                                                     // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"collections":{"books.js":["meteor/mongo","meteor/jagi:astronomy","../helpers",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collections/books.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Books:function(){return Books},Chapter:function(){return Chapter},Book:function(){return Book}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Class;module.import('meteor/jagi:astronomy',{"Class":function(v){Class=v}});var globalizeData;module.import('../helpers',{"globalizeData":function(v){globalizeData=v}});
                                                                                                                      // 2
                                                                                                                      //
                                                                                                                      // 4
                                                                                                                      //
var Books = new Mongo.Collection('books');                                                                            // 6
                                                                                                                      //
function convertToUrlStr(str) {                                                                                       // 8
    return str.toLowerCase().replace(/[^\w ]+/g, ' ').replace(/ +/g, '-');                                            // 10
}                                                                                                                     // 14
                                                                                                                      //
var Chapter = Class.create({                                                                                          // 16
    name: 'Chapter',                                                                                                  // 17
    /* No collection attribute */                                                                                     //
    fields: {                                                                                                         // 19
        meta: {                                                                                                       // 20
            type: Object                                                                                              // 21
        },                                                                                                            // 20
        content: {                                                                                                    // 23
            type: String                                                                                              // 24
        }                                                                                                             // 23
    }                                                                                                                 // 19
});                                                                                                                   // 16
                                                                                                                      //
var Book = Class.create({                                                                                             // 29
    name: 'Book',                                                                                                     // 30
    collection: Books,                                                                                                // 31
    fields: {                                                                                                         // 32
        title: String,                                                                                                // 33
        urlTitle: String,                                                                                             // 34
        index: Chapter,                                                                                               // 35
        chapters: [Chapter]                                                                                           // 36
    },                                                                                                                // 32
    events: {                                                                                                         // 38
        beforeSave: function beforeSave(e) {                                                                          // 39
            /* Do something before saving document */                                                                 //
            e.currentTarget.urlTitle = convertToUrlStr(e.currentTarget.title);                                        // 41
        }                                                                                                             // 42
    }                                                                                                                 // 38
});                                                                                                                   // 29
                                                                                                                      //
globalizeData({ Books: Books }, { Book: Book });                                                                      // 46
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"instructor.js":["meteor/mongo","meteor/jagi:astronomy","../helpers",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collections/instructor.js                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Instructors:function(){return Instructors},Instructor:function(){return Instructor}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var Class;module.import('meteor/jagi:astronomy',{"Class":function(v){Class=v}});var globalizeData;module.import('../helpers',{"globalizeData":function(v){globalizeData=v}});
                                                                                                                      // 2
                                                                                                                      //
                                                                                                                      // 4
                                                                                                                      //
var Instructors = new Mongo.Collection('instructors');                                                                // 6
                                                                                                                      //
var Instructor = Class.create({                                                                                       // 8
    name: 'Instructor',                                                                                               // 9
    collection: Instructors,                                                                                          // 10
    fields: {                                                                                                         // 11
        name: String                                                                                                  // 12
    }                                                                                                                 // 11
});                                                                                                                   // 8
                                                                                                                      //
globalizeData({ Instructors: Instructors }, { Instructor: Instructor });                                              // 16
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"helpers.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/helpers.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({globalizeData:function(){return globalizeData}});function globalizeData(mongoCollection, astroClass) {
  if (process.env.NODE_ENV === 'development') {                                                                       // 2
    global.Collections = Object.assign({}, global.Collections, mongoCollection);                                      // 3
    global.Models = Object.assign({}, global.Models, astroClass);                                                     // 4
  }                                                                                                                   // 5
}                                                                                                                     // 6
                                                                                                                      //
/*eslint-disable*/                                                                                                    //
// Better rounding function, courtesy of MDN                                                                          //
(function () {                                                                                                        // 10
  /**                                                                                                                 //
   * Decimal adjustment of a number.                                                                                  //
   *                                                                                                                  //
   * @param {String}  type  The type of adjustment.                                                                   //
   * @param {Number}  value The number.                                                                               //
   * @param {Integer} exp   The exponent (the 10 logarithm of the adjustment base).                                   //
   * @returns {Number} The adjusted value.                                                                            //
   */                                                                                                                 //
  function decimalAdjust(type, value, exp) {                                                                          // 19
    // If the exp is undefined or zero...                                                                             //
    if (typeof exp === 'undefined' || +exp === 0) {                                                                   // 21
      return Math[type](value);                                                                                       // 22
    }                                                                                                                 // 23
    value = +value;                                                                                                   // 24
    exp = +exp;                                                                                                       // 25
    // If the value is not a number or the exp is not an integer...                                                   //
    if (isNaN(value) || !(typeof exp === 'number' && exp % 1 === 0)) {                                                // 27
      return NaN;                                                                                                     // 28
    }                                                                                                                 // 29
    // Shift                                                                                                          //
    value = value.toString().split('e');                                                                              // 31
    value = Math[type](+(value[0] + 'e' + (value[1] ? +value[1] - exp : -exp)));                                      // 32
    // Shift back                                                                                                     //
    value = value.toString().split('e');                                                                              // 34
    return +(value[0] + 'e' + (value[1] ? +value[1] + exp : exp));                                                    // 35
  }                                                                                                                   // 36
                                                                                                                      //
  // Decimal round                                                                                                    //
  if (!Math.round10) {                                                                                                // 39
    Math.round10 = function (value, exp) {                                                                            // 40
      return decimalAdjust('round', value, exp);                                                                      // 41
    };                                                                                                                // 42
  }                                                                                                                   // 43
  // Decimal floor                                                                                                    //
  if (!Math.floor10) {                                                                                                // 45
    Math.floor10 = function (value, exp) {                                                                            // 46
      return decimalAdjust('floor', value, exp);                                                                      // 47
    };                                                                                                                // 48
  }                                                                                                                   // 49
  // Decimal ceil                                                                                                     //
  if (!Math.ceil10) {                                                                                                 // 51
    Math.ceil10 = function (value, exp) {                                                                             // 52
      return decimalAdjust('ceil', value, exp);                                                                       // 53
    };                                                                                                                // 54
  }                                                                                                                   // 55
})();                                                                                                                 // 56
/*eslint-enable*/                                                                                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["../imports/startup/server/",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.import('../imports/startup/server/');                                                                          // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
