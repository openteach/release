(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;

/* Package-scope variables */
var GitHub;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// packages/bruz_github-api/packages/bruz_github-api.js                                //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/bruz:github-api/github-api.js                                        //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
/*jshint expr:true*/                                                             // 1
                                                                                 // 2
var Future = Npm.require("fibers/future");                                       // 3
                                                                                 // 4
/**                                                                              // 5
 * Creates an instance of the github class.                                      // 6
 *                                                                               // 7
 * @param {Object} An object containing the target version of the GitHub API     // 8
 * and, optionally, a timeout for calls to the GitHub API.                       // 9
 */                                                                              // 10
GitHub = function(config) {                                                      // 11
  var wrap, target,                                                              // 12
      Module = Npm.require("github"),                                            // 13
      interface = new Module(config),                                            // 14
      rx = /[1-3]\.0\.0/;                                                        // 15
                                                                                 // 16
  /**                                                                            // 17
   * Wraps an asynchronous function in a future, making it synchronous.          // 18
   *                                                                             // 19
   * @param {Function} The function to be wrapped in a future.                   // 20
   * @return A future-backed promise.                                            // 21
   */                                                                            // 22
  wrap = function(fn) {                                                          // 23
    return function() {                                                          // 24
      var future = new Future(),                                                 // 25
          args = _.toArray(arguments),                                           // 26
          lastArg = _.last(args);                                                // 27
                                                                                 // 28
      // If a callback is provided, wrap it in a future without changing the     // 29
      // called function's API                                                   // 30
      if (_.isFunction(lastArg)) {                                               // 31
        args[args.length - 1] = function(error, data) {                          // 32
          if (error) {                                                           // 33
            future.throw(error);                                                 // 34
          } else {                                                               // 35
            lastArg(error, data);                                                // 36
            future.return();                                                     // 37
          }                                                                      // 38
        };                                                                       // 39
      } else {                                                                   // 40
        // If no callback is provided, set up a default one backed by a future   // 41
        args.push(function(error, data) {                                        // 42
          if (error) {                                                           // 43
            future.throw(error);                                                 // 44
          } else {                                                               // 45
            future.return(data);                                                 // 46
          }                                                                      // 47
        });                                                                      // 48
      }                                                                          // 49
                                                                                 // 50
      fn.apply(this, args);                                                      // 51
      return future.wait();                                                      // 52
    };                                                                           // 53
  };                                                                             // 54
                                                                                 // 55
  // Get a list of the modules that contain functions we need to modify.         // 56
  // interface['3.0.0'].routes (subbing in a different API version as necessary) // 57
  // will give us the names of all these modules.                                // 58
  //                                                                             // 59
  // TODO: Can we make this less janky/fragile?                                  // 60
  target = _.filter(interface, function(val, name) {                             // 61
    return rx.test(name);                                                        // 62
  })[0].routes;                                                                  // 63
                                                                                 // 64
  // Iterate over all modules and shim each method to be synchronous. Guard      // 65
  // against iterating over non-objects and against modifying non-functions.     // 66
  _.each(interface, function(obj) {                                              // 67
    if (_.isObject(obj)) {                                                       // 68
      _.each(obj, function(fn, name, module) {                                   // 69
        if (_.isFunction(fn)) {                                                  // 70
          module[name] = wrap(fn);                                               // 71
        }                                                                        // 72
      });                                                                        // 73
    }                                                                            // 74
  });                                                                            // 75
                                                                                 // 76
  return interface;                                                              // 77
};                                                                               // 78
                                                                                 // 79
///////////////////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['bruz:github-api'] = {}, {
  GitHub: GitHub
});

})();

//# sourceMappingURL=bruz_github-api.js.map
